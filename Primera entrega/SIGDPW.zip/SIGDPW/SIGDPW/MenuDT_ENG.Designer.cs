﻿namespace SIGDPW
{
    partial class MenuDT_ENG
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.lbxPartidosF = new System.Windows.Forms.ListBox();
            this.btnAgregarJugador = new System.Windows.Forms.Button();
            this.btnCargarFicha = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lbxPartidosR = new System.Windows.Forms.ListBox();
            this.btneEiminar = new System.Windows.Forms.Button();
            this.btnHabilitar = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.lbxJugadoresD = new System.Windows.Forms.ListBox();
            this.lbxJugadores = new System.Windows.Forms.ListBox();
            this.btnAtras = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btndeshabilitar = new System.Windows.Forms.Button();
            this.btnVerResultado = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(219, 377);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 17);
            this.label4.TabIndex = 30;
            this.label4.Text = "Future Matches";
            // 
            // lbxPartidosF
            // 
            this.lbxPartidosF.FormattingEnabled = true;
            this.lbxPartidosF.Location = new System.Drawing.Point(55, 394);
            this.lbxPartidosF.Name = "lbxPartidosF";
            this.lbxPartidosF.Size = new System.Drawing.Size(473, 160);
            this.lbxPartidosF.TabIndex = 29;
            // 
            // btnAgregarJugador
            // 
            this.btnAgregarJugador.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAgregarJugador.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregarJugador.Location = new System.Drawing.Point(660, 193);
            this.btnAgregarJugador.Name = "btnAgregarJugador";
            this.btnAgregarJugador.Size = new System.Drawing.Size(75, 23);
            this.btnAgregarJugador.TabIndex = 28;
            this.btnAgregarJugador.Text = "Add Player";
            this.btnAgregarJugador.UseVisualStyleBackColor = true;
            // 
            // btnCargarFicha
            // 
            this.btnCargarFicha.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCargarFicha.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCargarFicha.Location = new System.Drawing.Point(660, 164);
            this.btnCargarFicha.Name = "btnCargarFicha";
            this.btnCargarFicha.Size = new System.Drawing.Size(75, 23);
            this.btnCargarFicha.TabIndex = 27;
            this.btnCargarFicha.Text = "Load Profile";
            this.btnCargarFicha.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(803, 416);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 17);
            this.label2.TabIndex = 26;
            this.label2.Text = "Disabled Players";
            // 
            // lbxPartidosR
            // 
            this.lbxPartidosR.FormattingEnabled = true;
            this.lbxPartidosR.Location = new System.Drawing.Point(55, 30);
            this.lbxPartidosR.Name = "lbxPartidosR";
            this.lbxPartidosR.Size = new System.Drawing.Size(354, 225);
            this.lbxPartidosR.TabIndex = 25;
            // 
            // btneEiminar
            // 
            this.btneEiminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btneEiminar.Location = new System.Drawing.Point(999, 528);
            this.btneEiminar.Name = "btneEiminar";
            this.btneEiminar.Size = new System.Drawing.Size(75, 26);
            this.btneEiminar.TabIndex = 24;
            this.btneEiminar.Text = "Delete";
            this.btneEiminar.UseVisualStyleBackColor = true;
            // 
            // btnHabilitar
            // 
            this.btnHabilitar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHabilitar.Location = new System.Drawing.Point(999, 482);
            this.btnHabilitar.Name = "btnHabilitar";
            this.btnHabilitar.Size = new System.Drawing.Size(75, 26);
            this.btnHabilitar.TabIndex = 23;
            this.btnHabilitar.Text = "Enable";
            this.btnHabilitar.UseVisualStyleBackColor = true;
            // 
            // btnModificar
            // 
            this.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificar.Location = new System.Drawing.Point(980, 119);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(94, 23);
            this.btnModificar.TabIndex = 22;
            this.btnModificar.Text = "Modify Player";
            this.btnModificar.UseVisualStyleBackColor = true;
            // 
            // lbxJugadoresD
            // 
            this.lbxJugadoresD.FormattingEnabled = true;
            this.lbxJugadoresD.Location = new System.Drawing.Point(741, 433);
            this.lbxJugadoresD.Name = "lbxJugadoresD";
            this.lbxJugadoresD.Size = new System.Drawing.Size(233, 186);
            this.lbxJugadoresD.TabIndex = 21;
            // 
            // lbxJugadores
            // 
            this.lbxJugadores.FormattingEnabled = true;
            this.lbxJugadores.Location = new System.Drawing.Point(741, 30);
            this.lbxJugadores.Name = "lbxJugadores";
            this.lbxJugadores.Size = new System.Drawing.Size(233, 381);
            this.lbxJugadores.TabIndex = 20;
            // 
            // btnAtras
            // 
            this.btnAtras.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAtras.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAtras.Location = new System.Drawing.Point(27, 596);
            this.btnAtras.Name = "btnAtras";
            this.btnAtras.Size = new System.Drawing.Size(53, 23);
            this.btnAtras.TabIndex = 19;
            this.btnAtras.Text = "Back";
            this.btnAtras.UseVisualStyleBackColor = true;
            this.btnAtras.Click += new System.EventHandler(this.btnAtras_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(839, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 17);
            this.label3.TabIndex = 32;
            this.label3.Text = "Players";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(163, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 17);
            this.label1.TabIndex = 31;
            this.label1.Text = "Recent Matches ";
            // 
            // btndeshabilitar
            // 
            this.btndeshabilitar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndeshabilitar.Location = new System.Drawing.Point(980, 148);
            this.btndeshabilitar.Name = "btndeshabilitar";
            this.btndeshabilitar.Size = new System.Drawing.Size(94, 23);
            this.btndeshabilitar.TabIndex = 33;
            this.btndeshabilitar.Text = "Disable";
            this.btndeshabilitar.UseVisualStyleBackColor = true;
            // 
            // btnVerResultado
            // 
            this.btnVerResultado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerResultado.Location = new System.Drawing.Point(424, 102);
            this.btnVerResultado.Name = "btnVerResultado";
            this.btnVerResultado.Size = new System.Drawing.Size(75, 23);
            this.btnVerResultado.TabIndex = 34;
            this.btnVerResultado.Text = "Result";
            this.btnVerResultado.UseVisualStyleBackColor = true;
            // 
            // MenuDT_ENG
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 636);
            this.Controls.Add(this.btnVerResultado);
            this.Controls.Add(this.btndeshabilitar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbxPartidosF);
            this.Controls.Add(this.btnAgregarJugador);
            this.Controls.Add(this.btnCargarFicha);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbxPartidosR);
            this.Controls.Add(this.btneEiminar);
            this.Controls.Add(this.btnHabilitar);
            this.Controls.Add(this.btnModificar);
            this.Controls.Add(this.lbxJugadoresD);
            this.Controls.Add(this.lbxJugadores);
            this.Controls.Add(this.btnAtras);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MenuDT_ENG";
            this.Text = "DT Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox lbxPartidosF;
        private System.Windows.Forms.Button btnAgregarJugador;
        private System.Windows.Forms.Button btnCargarFicha;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lbxPartidosR;
        private System.Windows.Forms.Button btneEiminar;
        private System.Windows.Forms.Button btnHabilitar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.ListBox lbxJugadoresD;
        private System.Windows.Forms.ListBox lbxJugadores;
        private System.Windows.Forms.Button btnAtras;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btndeshabilitar;
        private System.Windows.Forms.Button btnVerResultado;
    }
}